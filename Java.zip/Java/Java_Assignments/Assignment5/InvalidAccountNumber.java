package Java_Assignments.Assignment5;

public class InvalidAccountNumber extends Exception {
    public InvalidAccountNumber(String message) {
        super(message);
    }
        
}
