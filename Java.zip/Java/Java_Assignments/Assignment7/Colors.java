package Java_Assignments.Assignment7;

import java.util.List;

public interface Colors {
    List<String> apply(List<String> c);
}

