package Java_Assignments.Assignment3.Q2;

//To call the default interface.

public class Test implements Printable {

}
