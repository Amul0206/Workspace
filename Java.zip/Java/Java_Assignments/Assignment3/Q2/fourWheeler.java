package Java_Assignments.Assignment3.Q2;

public class fourWheeler extends Vehicle {

    public fourWheeler(String model, String manufacturer, int policyNumber, String policyHolder, String policyStartDate, int policyAmount, int period, int seatingCapacity, String fuelType) {
        super(model, manufacturer, policyNumber, policyHolder, policyStartDate, policyAmount, period, fuelType);
    }
}
