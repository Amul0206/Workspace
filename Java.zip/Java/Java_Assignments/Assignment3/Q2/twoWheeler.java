package Java_Assignments.Assignment3.Q2;

public class twoWheeler extends Vehicle {


    public twoWheeler(String model, String manufacturer, int policyNumber, String policyHolder, String policyStartDate, int policyAmount, int period, int engineCapacity, String fuelType) {
        super(model, manufacturer, policyNumber, policyHolder, policyStartDate, policyAmount, period, fuelType);
    }
}
