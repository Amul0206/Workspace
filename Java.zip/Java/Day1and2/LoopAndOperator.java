package Java.Day1and2;

public class LoopAndOperator {
    
}
