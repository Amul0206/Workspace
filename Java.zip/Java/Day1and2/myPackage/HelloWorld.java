package Java.Day1and2.myPackage;

public class HelloWorld{
    public void greet(){
        System.out.println("Hello, World!");
    }
}