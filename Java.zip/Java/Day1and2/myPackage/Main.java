package Java.Day1and2.myPackage;

public class Main {
    public static void main(String[] args) {
        HelloWorld hello = new HelloWorld();
        hello.greet();
    }
}


