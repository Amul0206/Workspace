package Java.Day1and2;

public class Calendar{
    public static void main(String[] args) {
        Date d1 = new Date();
        System.out.println(d1);

        //Date d2 = new Date();
        //d2.setDate(23, "March", 2025);
    }
}