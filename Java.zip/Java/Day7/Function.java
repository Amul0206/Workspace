package Java.Day7;

public interface Function {
    int apply(int n);
}
