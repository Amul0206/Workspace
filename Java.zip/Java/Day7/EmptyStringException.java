package Java.Day7;

public class EmptyStringException extends Exception {

    public EmptyStringException(String message) {
        super();
    }
}
