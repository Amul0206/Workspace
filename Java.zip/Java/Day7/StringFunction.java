package Java.Day7;

public interface StringFunction {
    String apply(String s) throws EmptyStringException;
}
