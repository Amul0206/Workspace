package Java.Day3.Folder2;
//import Java\DAY3\Folder1\bin\JAVA\DAY3.Folder1.src.Date1;

public class Calendar{
    // public static void main(String[] args) {
    //     Date1 d1 = new Date1();
    //     System.out.println(d1);

    //     Date1 d2 = new Date1();
    //     d2.setDate(23, "March", 2025);
    // }
}