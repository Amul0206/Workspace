package PRACTICE.Inheritance;

public class Test {
    

}
