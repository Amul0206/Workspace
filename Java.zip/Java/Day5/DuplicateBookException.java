package Java.Day5;

public class DuplicateBookException extends Exception{

    public DuplicateBookException(String message){
        super(message);
    }

}
