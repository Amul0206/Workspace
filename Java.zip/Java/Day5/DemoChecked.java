// package Java.Day5;
// import java.io.File;
// import java.io.IOException;
// public class DemoChecked {

//     public void createFile(String file){
//         File f = new File(file);

//         if(!f.exists()){
//             f.createNewFile();
//         }
//     }
//     public static void main(String[] args) {
//         try{
//             DemoChecked.createFile("test.txt");
//         }
//         catch(IOException e){
//             e.printStackTrace();
//         }
//         finally{
//             System.out.println("After try-catch");
//         }
        



//     }
// }
